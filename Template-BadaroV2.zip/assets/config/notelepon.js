document.write('<a href="tel:+6285881732843" class="btn btn-text-primary" >PANGGIL</a>')
//Ganti +6285159997692 dengan NO Telepon Agan (Gunakan Kode Negara +62)
//Jangan Menghapus kode scriptnya