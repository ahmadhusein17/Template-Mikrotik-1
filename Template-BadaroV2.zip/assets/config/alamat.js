document.write('Ahmad Husein, RT 12/RW 011 No.81')
//Sesuaikan, Jika ingin menggunakan karakter "enter" gunakan kode <br>
//Jangan Menghapus kode scriptnya