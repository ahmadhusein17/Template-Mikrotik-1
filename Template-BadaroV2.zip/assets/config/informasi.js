document.write('PROMO PASANG BARU MULAI 150RIBU UNTUK 5 PERANGKAT.... HUBUNGU KAMI MELALUI MENU BANTUAN')
//Sesuaikan
//Jangan Menghapus kode scriptnya