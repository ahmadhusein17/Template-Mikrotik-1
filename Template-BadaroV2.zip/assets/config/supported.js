document.write('Juragan Rezeki Mulia')
//Sesuaikan
//Jangan Menghapus kode scriptnya