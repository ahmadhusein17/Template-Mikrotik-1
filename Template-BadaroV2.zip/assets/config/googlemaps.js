document.write(
  '<a href="https://api.whatsapp.com/send?phone=6285881732843" class="btn btn-success">WhatsApp</a>'
);
//Sesuaikan LinkGOOGLEMaps dengan link lokasi kantor agan
//Jangan Menghapus kode scriptnya
