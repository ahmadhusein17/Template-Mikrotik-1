document.write('Juragan Rezeki Mulia')
//Ganti BADARO.ID dengan Nama Wifi Agan
//Jangan Menghapus kode scriptnya